// Validierung des Bestellformulars
document.addEventListener('DOMContentLoaded', function() {
    // Bestellformular
    var orderForm = document.getElementById('orderForm');
    if (orderForm) {
        orderForm.addEventListener('submit', function(event) {
            event.preventDefault();

            // Formulardaten abrufen
            var firstName = document.getElementById('firstName').value.trim();
            var lastName = document.getElementById('lastName').value.trim();
            var email = document.getElementById('email').value.trim();
            var pickup = document.getElementById('pickup').value.trim();
            var destination = document.getElementById('destination').value.trim();
            var date = document.getElementById('date').value;

            // Validierung
            if (!firstName || !lastName || !email || !pickup || !destination || !date) {
                alert('Bitte füllen Sie alle mit * gekennzeichneten Felder aus.');
                return;
            }

            // E-Mail-Format prüfen
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                alert('Bitte geben Sie eine gültige E-Mail-Adresse ein.');
                return;
            }

            // Formulardaten in der Konsole ausgeben
            console.log('Vorname:', firstName);
            console.log('Nachname:', lastName);
            console.log('Telefon:', document.getElementById('phone').value.trim());
            console.log('E-Mail:', email);
            console.log('Abholort:', pickup);
            console.log('Zielort:', destination);
            console.log('Datum und Uhrzeit:', date);
            console.log('Nachricht:', document.getElementById('message').value.trim());
            console.log('Zeitstempel:', new Date().toLocaleString());

            alert('Vielen Dank für Ihre Bestellung! Wir werden uns in Kürze mit Ihnen in Verbindung setzen.');
            orderForm.reset();
        });
    }

    // Kontaktformular
    var contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault();

            // Formulardaten abrufen
            var name = document.getElementById('name').value.trim();
            var email = document.getElementById('email').value.trim();
            var subject = document.getElementById('subject').value.trim();
            var message = document.getElementById('message').value.trim();

            // Validierung
            if (!name || !email || !subject || !message) {
                alert('Bitte füllen Sie alle mit * gekennzeichneten Felder aus.');
                return;
            }

            // E-Mail-Format prüfen
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                alert('Bitte geben Sie eine gültige E-Mail-Adresse ein.');
                return;
            }

            // Formulardaten in der Konsole ausgeben
            console.log('Name:', name);
            console.log('E-Mail:', email);
            console.log('Betreff:', subject);
            console.log('Nachricht:', message);
            console.log('Zeitstempel:', new Date().toLocaleString());

            alert('Vielen Dank für Ihre Nachricht! Wir werden uns in Kürze bei Ihnen melden.');
            contactForm.reset();
        });
    }
});
